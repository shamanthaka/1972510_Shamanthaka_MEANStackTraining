npm i --save socket.io

npm i --save-dev nodemon